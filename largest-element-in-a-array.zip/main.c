/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
//Program to print largest element in a given array
int main()
{
    int n;
    printf("enter the value of n:");
    scanf("%d",&n);
    int arr[n];
    printf("enter %d elements:\n",n);
    for(int i=0;i<=n-1;i++){
        scanf("%d",&arr[i]);
    }
    int big = arr[0];
    for(int i=1;i<n;i++){
        if(arr[i]>big){
            big = arr[i];
           
        } }printf("%d",big);
    

    return 0;
}